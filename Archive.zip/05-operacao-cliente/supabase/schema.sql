-- ============================================================================
-- HIBRID — Briefing de demanda ecommerce
-- Schema Supabase / Postgres
-- ----------------------------------------------------------------------------
-- Estrutura da tabela `briefings` que recebe as submissões do formulário
-- (arquivo briefing-demanda-ecommerce.html).
--
-- Para aplicar:
--   1. Abra o SQL editor do Supabase
--   2. Cole este arquivo inteiro
--   3. Run
--
-- Para reverter, rode `drop-schema.sql` (gerado a partir desse arquivo).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TABELA PRINCIPAL
-- ----------------------------------------------------------------------------

create table if not exists briefings (
  -- Metadados
  id                          uuid            primary key default gen_random_uuid(),
  created_at                  timestamptz     not null default now(),
  updated_at                  timestamptz     not null default now(),
  status                      text            not null default 'pendente'
                              check (status in ('pendente','em_execucao','aguardando_cliente','concluido','cancelado')),

  -- 01 — Identificação
  cliente_loja                text            not null,
  cliente_solicitante         text            not null,

  -- 02 — Tipo de demanda
  tipo                        text            not null
                              check (tipo in ('criativos','nova_campanha')),

  -- 03 — Campanha
  -- 'nova_campanha': campanha_nome + canais + objetivo obrigatórios
  -- 'criativos': só campanha_existente obrigatório (referencia a campanha pai)
  campanha_nome               text,
  campanha_existente          text,
  canais                      text[]          not null default '{}',
  google_tipo                 text[]          default '{}',
  objetivo                    text,

  -- 04 — Oferta / Destino
  -- 'nova_campanha': oferta_produto + oferta_tipos + oferta_frase + url_destino obrigatórios
  -- 'criativos': só url_destino obrigatório
  oferta_produto              text,
  oferta_tipos                text[]          not null default '{}',
  oferta_frase                text,
  cupom                       text,
  cupom_condicoes             text,
  url_destino                 text            not null
                              check (url_destino ~* '^https?://'),

  -- 05 — Período & Investimento (campos null quando tipo='criativos' — campanha já em curso)
  data_inicio                 date,
  data_fim                    date,
  invest_tipo                 text
                              check (invest_tipo in ('budget','extra')),
  invest_valor_extra          numeric(12,2),

  -- 06 — Criativos
  drive_links                 text[]          not null
                              check (cardinality(drive_links) >= 1),
  drive_acesso_confirmado     boolean         not null default false,
  formatos                    text[]          default '{}',
  copies_prontas              text
                              check (copies_prontas in ('sim','parcial','nao')),
  headlines                   text[]          default '{}',

  -- 07 — Público
  idade_min                   integer         check (idade_min between 13 and 99),
  idade_max                   integer         check (idade_max between 13 and 99),
  sexo                        text            default 'todos'
                              check (sexo in ('todos','feminino','masculino')),
  segmentacao_obs             text,

  -- Constraints adicionais
  constraint idade_range_valido check (idade_min is null or idade_max is null or idade_min <= idade_max),
  constraint datas_validas      check (data_inicio is null or data_fim is null or data_inicio <= data_fim),
  -- Quando tipo='criativos': apenas campanha_existente + url_destino são exigidos.
  -- Quando tipo='nova_campanha': nome, canais, oferta completa e investimento.
  constraint criativos_completos check (
    tipo <> 'criativos' or (
      campanha_existente is not null and url_destino is not null
    )
  ),
  constraint nova_campanha_completa check (
    tipo <> 'nova_campanha' or (
      campanha_nome is not null
      and cardinality(canais) >= 1
      and oferta_produto is not null
      and oferta_frase is not null
      and cardinality(oferta_tipos) >= 1
      and invest_tipo is not null
    )
  )
);

comment on table briefings is
  'Submissões do formulário público de briefing de demanda (ecommerce). Cada linha = uma demanda enviada pelo cliente.';

-- ----------------------------------------------------------------------------
-- 2. ÍNDICES
-- ----------------------------------------------------------------------------

create index if not exists idx_briefings_status      on briefings(status);
create index if not exists idx_briefings_created_at  on briefings(created_at desc);
create index if not exists idx_briefings_cliente     on briefings(cliente_loja);
create index if not exists idx_briefings_tipo        on briefings(tipo);

-- ----------------------------------------------------------------------------
-- 3. TRIGGER updated_at
-- ----------------------------------------------------------------------------

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists briefings_set_updated_at on briefings;
create trigger briefings_set_updated_at
  before update on briefings
  for each row execute function set_updated_at();

-- ----------------------------------------------------------------------------
-- 4. ROW LEVEL SECURITY (RLS)
-- ----------------------------------------------------------------------------
-- O formulário é público (qualquer pessoa pode submeter), mas apenas o time
-- autenticado da Hibrid pode ler, atualizar ou deletar.
-- ----------------------------------------------------------------------------

alter table briefings enable row level security;

-- Insert público — qualquer pessoa (anon) pode criar um briefing
drop policy if exists "publico pode criar briefings" on briefings;
create policy "publico pode criar briefings"
  on briefings
  for insert
  to anon, authenticated
  with check (true);

-- Select — apenas usuários autenticados (time Hibrid)
drop policy if exists "time hibrid le briefings" on briefings;
create policy "time hibrid le briefings"
  on briefings
  for select
  to authenticated
  using (true);

-- Update — apenas autenticados (mudar status, adicionar anotações)
drop policy if exists "time hibrid atualiza briefings" on briefings;
create policy "time hibrid atualiza briefings"
  on briefings
  for update
  to authenticated
  using (true)
  with check (true);

-- Delete — apenas autenticados
drop policy if exists "time hibrid deleta briefings" on briefings;
create policy "time hibrid deleta briefings"
  on briefings
  for delete
  to authenticated
  using (true);

-- ----------------------------------------------------------------------------
-- 5. VIEWS ÚTEIS (opcional)
-- ----------------------------------------------------------------------------
-- View com briefings pendentes ordenados por urgência implícita (recentes
-- primeiro). Útil pra dashboard do time.
-- ----------------------------------------------------------------------------

create or replace view v_briefings_fila as
select
  id,
  created_at,
  status,
  cliente_loja,
  cliente_solicitante,
  campanha_nome,
  tipo,
  canais,
  invest_tipo,
  invest_valor_extra,
  data_inicio,
  cardinality(drive_links) as qtd_pastas_drive,
  drive_acesso_confirmado
from briefings
where status in ('pendente','em_execucao','aguardando_cliente')
order by
  case status
    when 'pendente' then 1
    when 'aguardando_cliente' then 2
    when 'em_execucao' then 3
  end,
  created_at desc;

comment on view v_briefings_fila is
  'Fila de briefings ativos ordenados por status e data. Use no dashboard do time.';
