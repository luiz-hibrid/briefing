# Schema Supabase — Briefings de demanda

Este diretório tem o schema da tabela que recebe as submissões do formulário público de briefing (`briefing-demanda-ecommerce.html`). Pensado pra ser aplicado direto no Supabase do projeto que será gerado no Lovable.

## Arquivos

- `schema.sql` — `CREATE TABLE briefings`, índices, trigger de `updated_at`, políticas de RLS e uma view de fila pro dashboard.

## Como aplicar

1. Crie um projeto Supabase (ou abra o que o Lovable conectou ao seu app).
2. Abra **SQL Editor → New query**.
3. Cole o conteúdo de `schema.sql` inteiro e clique **Run**.
4. Confira em **Table Editor** se a tabela `briefings` apareceu com todas as colunas.

Pra reaplicar (idempotente): o arquivo usa `create table if not exists`, `drop policy if exists`, `create or replace function/view`, então rodar de novo não duplica nada.

## Estrutura da tabela

Cada submissão do formulário vira **uma linha** em `briefings`. A maioria dos campos é tipada (text, integer, date, boolean) pra facilitar queries; alguns são `text[]` (arrays) por serem múltipla seleção:

| Bloco do form | Colunas |
|---|---|
| Metadados | `id`, `created_at`, `updated_at`, `status` |
| 01 Identificação | `cliente_loja`, `cliente_solicitante` |
| 02 Tipo | `tipo` ∈ {`criativos`, `nova_campanha`} |
| 03 Campanha | `campanha_nome`, `campanha_existente`, `canais[]`, `google_tipo[]`, `objetivo` |
| 04 Oferta | `oferta_produto`, `oferta_tipos[]`, `oferta_frase`, `cupom`, `cupom_condicoes`, `url_destino` |
| 05 Período & Investimento | `data_inicio`, `data_fim`, `invest_tipo` ∈ {`budget`, `extra`}, `invest_valor_extra` |
| 06 Criativos | `drive_links[]`, `drive_acesso_confirmado`, `formatos[]`, `copies_prontas`, `headlines[]` |
| 07 Público | `idade_min`, `idade_max`, `sexo`, `segmentacao_obs` |

Os valores das enums (textos curtos como `nova_campanha`, `vendas`, `desconto`) seguem exatamente os `value=""` dos inputs no HTML — então o front pode mandar `tipo: 'nova_campanha'` direto sem mapping.

## Workflow de status

A coluna `status` arbitra o ciclo de vida da demanda:

- `pendente` — recém-chegou, ainda não foi triada pelo time.
- `em_execucao` — equipe assumiu, está produzindo.
- `aguardando_cliente` — falta retorno do cliente (ex: acesso ao Drive não liberado).
- `concluido` — campanha no ar / criativo subido.
- `cancelado` — demanda descartada.

A view `v_briefings_fila` já filtra os três primeiros e ordena por prioridade — use ela no dashboard interno.

## RLS — quem pode fazer o quê

| Operação | `anon` (formulário público) | `authenticated` (time Hibrid) |
|---|---|---|
| `INSERT` | sim | sim |
| `SELECT` | não | sim |
| `UPDATE` | não | sim |
| `DELETE` | não | sim |

Ou seja: o cliente pode submeter o briefing sem login, mas só o time logado consegue ler. Se você quiser depois restringir leitura por cliente (ex: cliente vê o histórico dele), basta adicionar `user_id uuid references auth.users` e ajustar a policy.

## Exemplo — insert pelo Supabase JS

A função `coletarPayload()` no JS do formulário já produz um objeto pronto:

```js
import { createClient } from '@supabase/supabase-js'
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

const payload = coletarPayload(); // do briefing-demanda-ecommerce.html

const { data, error } = await supabase
  .from('briefings')
  .insert({
    // 01
    cliente_loja: payload.cliente.loja,
    cliente_solicitante: payload.cliente.solicitante,
    // 02
    tipo: payload.tipo,
    // 03
    campanha_nome: payload.campanha.nome,
    campanha_existente: payload.campanha.campanha_existente,
    canais: payload.campanha.canais,
    google_tipo: payload.campanha.google_tipo,
    objetivo: payload.campanha.objetivo,
    // 04
    oferta_produto: payload.oferta.produto,
    oferta_tipos: payload.oferta.tipos,
    oferta_frase: payload.oferta.frase,
    cupom: payload.oferta.cupom,
    cupom_condicoes: payload.oferta.cupom_condicoes,
    url_destino: payload.oferta.url_destino,
    // 05
    data_inicio: payload.periodo_investimento.data_inicio,
    data_fim: payload.periodo_investimento.data_fim,
    invest_tipo: payload.periodo_investimento.tipo,
    invest_valor_extra: payload.periodo_investimento.valor_extra,
    // 06
    drive_links: payload.criativos.drive_links,
    drive_acesso_confirmado: payload.criativos.acesso_confirmado,
    formatos: payload.criativos.formatos,
    copies_prontas: payload.criativos.copies_prontas,
    headlines: payload.criativos.headlines,
    // 07
    idade_min: payload.publico.idade_min,
    idade_max: payload.publico.idade_max,
    sexo: payload.publico.sexo,
    segmentacao_obs: payload.publico.observacoes
  })
  .select()
  .single()

if (error) throw error
// data.id agora pode ser usado para mostrar confirmação
```

## Próximos passos sugeridos

Quando estiver no Lovable, considere adicionar:

1. **Notificação para o time** quando um briefing entra (Edge Function chamando webhook do Slack/Discord ou e-mail).
2. **Painel interno** simples listando `v_briefings_fila` com mudança de status inline.
3. **Storage bucket** se um dia quiser receber arquivos direto (hoje basta o link do Drive).
4. **Histórico por cliente** — adicionar `user_id` se o cliente fizer login, ou `cliente_loja` como chave de agrupamento.
